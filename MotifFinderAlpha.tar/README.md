# motif_finding
Bioinformatics project fall 2015
Team Alpha

The code is localized in a single file: motif_finder.c
In order to compile the code, simply run "make". The makefile is preconfigured to compile with the correct arguments.
Once compiled, the code can be run as specified in the instructions. If the current directory is not in the path variable, then the program should be run as "./MotifFinder".